 
================================================================================

Helvetica and Helvetica Neue fonts do not come preinstalled on PC but 
they do on the Mac. Therefore there are many formats and poor conversions 
circulating out there, which leads to different naming, messed up font grouping
and broken fonts in web browsers. 

Not any more!

================================================================================

HELVETICA and HELVETICA NEUE original fonts freshly converted for PC!

This ZIP includes:
-Helvetica (TTF, 6 styles)
-Helvetica Neue(OTF, 11 styles)
-Helvetica Neue LT Std (OTF, 51 styles!)
bonus: original Mac .dfont files for Helvetica and Helvetica Neue

FEATURES:
-original Mac fonts converted to PC friendly formats
-the fonts look consistent between the two platforms
-the fonts group-up nicely by family and styles in Photoshop, Illustrator, etc
-it is all you every really need. go ahead and erase all that Helvetica mess
-Helvetica Neue LT Std is published by Adobe and is virtually identical 
to Helvetica Neue. Except it has 51 styles, covering everything from 
Thin Condensed to Black Extended Oblique.

================================================================================
USEFUL LINKS:

If you want to convert your own .dfonts from Mac to all other 
PC friendly formats use FontForge:
http://sourceforge.net/projects/fontforge/files/fontforge-source/

For what's different between Helvetica and Helvetica Neue:
http://www.fonts.com/content/learning/fyti/typefaces/helvetica-old-and-neue

More info and a preview of Adobe's Helvetica Neue LT Std here:
http://www.myfonts.com/fonts/adobe/helvetica-neue/

================================================================================

If you have troubles removing your old Helvetica fonts from Windows then:
1. Boot up in "Safe mode with command prompt" by pressing F8 before Win starts.
2. In command prompt mode type "cd c:\windows\fonts", hit enter.
3. Type "dir helv*.*", hit enter and make sure your font files are listed there.
4. Then type "del helv*.*" and hit enter.
This will erase all files that start with "helv" from that folder.
NOTE: Be careful what you do and use common sense!

================================================================================
Happy downloading, don't forget to seed it!